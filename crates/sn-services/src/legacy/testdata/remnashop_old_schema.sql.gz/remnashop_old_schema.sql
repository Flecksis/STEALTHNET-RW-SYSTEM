--
-- PostgreSQL database dump
--

\restrict ATr5PXLfugRydJ0grQ5uW5fOGIY6XPpP8G2XY4LgBni7HAB36P8E1wr6S54ymi0

-- Dumped from database version 16.15 (Homebrew)
-- Dumped by pg_dump version 16.15 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: broadcast_audience; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.broadcast_audience AS ENUM (
    'ALL',
    'PLAN',
    'SUBSCRIBED',
    'UNSUBSCRIBED',
    'EXPIRED',
    'TRIAL'
);


ALTER TYPE public.broadcast_audience OWNER TO postgres;

--
-- Name: broadcast_message_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.broadcast_message_status AS ENUM (
    'SENT',
    'FAILED',
    'EDITED',
    'DELETED',
    'PENDING'
);


ALTER TYPE public.broadcast_message_status OWNER TO postgres;

--
-- Name: broadcast_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.broadcast_status AS ENUM (
    'PROCESSING',
    'COMPLETED',
    'CANCELED',
    'DELETED',
    'ERROR'
);


ALTER TYPE public.broadcast_status OWNER TO postgres;

--
-- Name: currency; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.currency AS ENUM (
    'USD',
    'XTR',
    'RUB'
);


ALTER TYPE public.currency OWNER TO postgres;

--
-- Name: locale; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.locale AS ENUM (
    'AR',
    'AZ',
    'BE',
    'CS',
    'DE',
    'EN',
    'ES',
    'FA',
    'FR',
    'HE',
    'HI',
    'ID',
    'IT',
    'JA',
    'KK',
    'KO',
    'MS',
    'NL',
    'PL',
    'PT',
    'RO',
    'RU',
    'SR',
    'TR',
    'UK',
    'UZ',
    'VI'
);


ALTER TYPE public.locale OWNER TO postgres;

--
-- Name: payment_gateway_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.payment_gateway_type AS ENUM (
    'TELEGRAM_STARS',
    'YOOKASSA',
    'YOOMONEY',
    'CRYPTOMUS',
    'HELEKET',
    'CRYPTOPAY',
    'FREEKASSA',
    'MULENPAY',
    'PAYMASTER',
    'PLATEGA',
    'ROBOKASSA',
    'URLPAY',
    'WATA'
);


ALTER TYPE public.payment_gateway_type OWNER TO postgres;

--
-- Name: plan_availability; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.plan_availability AS ENUM (
    'ALL',
    'NEW',
    'EXISTING',
    'INVITED',
    'ALLOWED',
    'LINK'
);


ALTER TYPE public.plan_availability OWNER TO postgres;

--
-- Name: plan_traffic_limit_strategy; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.plan_traffic_limit_strategy AS ENUM (
    'NO_RESET',
    'DAY',
    'WEEK',
    'MONTH',
    'MONTH_ROLLING'
);


ALTER TYPE public.plan_traffic_limit_strategy OWNER TO postgres;

--
-- Name: plan_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.plan_type AS ENUM (
    'TRAFFIC',
    'DEVICES',
    'BOTH',
    'UNLIMITED'
);


ALTER TYPE public.plan_type OWNER TO postgres;

--
-- Name: promocode_reward_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.promocode_reward_type AS ENUM (
    'DURATION',
    'TRAFFIC',
    'SUBSCRIPTION',
    'PERSONAL_DISCOUNT',
    'PURCHASE_DISCOUNT'
);


ALTER TYPE public.promocode_reward_type OWNER TO postgres;

--
-- Name: purchase_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.purchase_type AS ENUM (
    'NEW',
    'RENEW',
    'CHANGE'
);


ALTER TYPE public.purchase_type OWNER TO postgres;

--
-- Name: referral_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.referral_level AS ENUM (
    'FIRST',
    'SECOND'
);


ALTER TYPE public.referral_level OWNER TO postgres;

--
-- Name: referral_reward_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.referral_reward_type AS ENUM (
    'POINTS',
    'EXTRA_DAYS'
);


ALTER TYPE public.referral_reward_type OWNER TO postgres;

--
-- Name: subscription_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.subscription_status AS ENUM (
    'ACTIVE',
    'DISABLED',
    'LIMITED',
    'EXPIRED',
    'DELETED'
);


ALTER TYPE public.subscription_status OWNER TO postgres;

--
-- Name: traffic_limit_strategy; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.traffic_limit_strategy AS ENUM (
    'NO_RESET',
    'DAY',
    'WEEK',
    'MONTH'
);


ALTER TYPE public.traffic_limit_strategy OWNER TO postgres;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transaction_status AS ENUM (
    'PENDING',
    'COMPLETED',
    'CANCELED',
    'REFUNDED',
    'FAILED'
);


ALTER TYPE public.transaction_status OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'DEV',
    'ADMIN',
    'USER',
    'PREVIEW',
    'OWNER',
    'SYSTEM'
);


ALTER TYPE public.user_role OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: broadcast_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.broadcast_messages (
    id integer NOT NULL,
    broadcast_id integer NOT NULL,
    user_telegram_id bigint NOT NULL,
    message_id bigint,
    status public.broadcast_message_status NOT NULL
);


ALTER TABLE public.broadcast_messages OWNER TO postgres;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.broadcast_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.broadcast_messages_id_seq OWNER TO postgres;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.broadcast_messages_id_seq OWNED BY public.broadcast_messages.id;


--
-- Name: broadcasts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.broadcasts (
    id integer NOT NULL,
    task_id uuid NOT NULL,
    status public.broadcast_status NOT NULL,
    audience public.broadcast_audience NOT NULL,
    total_count integer NOT NULL,
    success_count integer NOT NULL,
    failed_count integer NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL
);


ALTER TABLE public.broadcasts OWNER TO postgres;

--
-- Name: broadcasts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.broadcasts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.broadcasts_id_seq OWNER TO postgres;

--
-- Name: broadcasts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.broadcasts_id_seq OWNED BY public.broadcasts.id;


--
-- Name: payment_gateways; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_gateways (
    id integer NOT NULL,
    order_index integer NOT NULL,
    type public.payment_gateway_type NOT NULL,
    currency public.currency NOT NULL,
    is_active boolean NOT NULL,
    settings jsonb
);


ALTER TABLE public.payment_gateways OWNER TO postgres;

--
-- Name: payment_gateways_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_gateways_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_gateways_id_seq OWNER TO postgres;

--
-- Name: payment_gateways_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_gateways_id_seq OWNED BY public.payment_gateways.id;


--
-- Name: plan_durations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_durations (
    id integer NOT NULL,
    days integer NOT NULL,
    plan_id integer NOT NULL,
    order_index integer NOT NULL
);


ALTER TABLE public.plan_durations OWNER TO postgres;

--
-- Name: plan_durations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_durations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_durations_id_seq OWNER TO postgres;

--
-- Name: plan_durations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_durations_id_seq OWNED BY public.plan_durations.id;


--
-- Name: plan_prices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_prices (
    id integer NOT NULL,
    currency public.currency NOT NULL,
    price numeric(10,2) NOT NULL,
    plan_duration_id integer NOT NULL
);


ALTER TABLE public.plan_prices OWNER TO postgres;

--
-- Name: plan_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_prices_id_seq OWNER TO postgres;

--
-- Name: plan_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_prices_id_seq OWNED BY public.plan_prices.id;


--
-- Name: plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plans (
    id integer NOT NULL,
    order_index integer NOT NULL,
    is_active boolean NOT NULL,
    type public.plan_type NOT NULL,
    availability public.plan_availability NOT NULL,
    name character varying NOT NULL,
    traffic_limit integer NOT NULL,
    device_limit integer NOT NULL,
    allowed_user_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    internal_squads uuid[] NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    description character varying,
    tag character varying,
    traffic_limit_strategy public.plan_traffic_limit_strategy DEFAULT 'NO_RESET'::public.plan_traffic_limit_strategy NOT NULL,
    external_squad uuid,
    is_trial boolean NOT NULL,
    public_code character varying NOT NULL
);


ALTER TABLE public.plans OWNER TO postgres;

--
-- Name: plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plans_id_seq OWNER TO postgres;

--
-- Name: plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plans_id_seq OWNED BY public.plans.id;


--
-- Name: referral_rewards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.referral_rewards (
    id integer NOT NULL,
    referral_id integer NOT NULL,
    user_telegram_id bigint NOT NULL,
    type public.referral_reward_type NOT NULL,
    amount integer NOT NULL,
    is_issued boolean NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL
);


ALTER TABLE public.referral_rewards OWNER TO postgres;

--
-- Name: referral_rewards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.referral_rewards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.referral_rewards_id_seq OWNER TO postgres;

--
-- Name: referral_rewards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.referral_rewards_id_seq OWNED BY public.referral_rewards.id;


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.referrals (
    id integer NOT NULL,
    referrer_telegram_id bigint NOT NULL,
    referred_telegram_id bigint NOT NULL,
    level public.referral_level NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL
);


ALTER TABLE public.referrals OWNER TO postgres;

--
-- Name: referrals_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.referrals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.referrals_id_seq OWNER TO postgres;

--
-- Name: referrals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.referrals_id_seq OWNED BY public.referrals.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    default_currency public.currency NOT NULL,
    referral jsonb DEFAULT '{"enable": true, "level": 1, "accrual_strategy": "ON_FIRST_PAYMENT", "reward": {"type": "EXTRA_DAYS", "strategy": "AMOUNT", "config": {"1": 5}}}'::json NOT NULL,
    access jsonb NOT NULL,
    requirements jsonb NOT NULL,
    notifications jsonb NOT NULL,
    menu jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    backup jsonb NOT NULL,
    blacklist jsonb NOT NULL
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    user_remna_id uuid NOT NULL,
    user_telegram_id bigint NOT NULL,
    status public.subscription_status NOT NULL,
    is_trial boolean NOT NULL,
    traffic_limit integer NOT NULL,
    device_limit integer NOT NULL,
    internal_squads uuid[] NOT NULL,
    expire_at timestamp with time zone NOT NULL,
    url character varying NOT NULL,
    plan_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    external_squad uuid,
    traffic_limit_strategy public.plan_traffic_limit_strategy NOT NULL,
    tag character varying
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subscriptions_id_seq OWNER TO postgres;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    payment_id uuid NOT NULL,
    user_telegram_id bigint NOT NULL,
    status public.transaction_status NOT NULL,
    is_test boolean NOT NULL,
    purchase_type public.purchase_type NOT NULL,
    gateway_type public.payment_gateway_type NOT NULL,
    pricing jsonb NOT NULL,
    currency public.currency NOT NULL,
    plan_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_id bigint NOT NULL,
    username character varying(32),
    name character varying NOT NULL,
    role public.user_role NOT NULL,
    language public.locale NOT NULL,
    personal_discount integer NOT NULL,
    purchase_discount integer NOT NULL,
    is_blocked boolean NOT NULL,
    is_bot_blocked boolean NOT NULL,
    current_subscription_id integer,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    referral_code character varying(64) NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    is_rules_accepted boolean NOT NULL,
    is_trial_available boolean NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: broadcast_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.broadcast_messages ALTER COLUMN id SET DEFAULT nextval('public.broadcast_messages_id_seq'::regclass);


--
-- Name: broadcasts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.broadcasts ALTER COLUMN id SET DEFAULT nextval('public.broadcasts_id_seq'::regclass);


--
-- Name: payment_gateways id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_gateways ALTER COLUMN id SET DEFAULT nextval('public.payment_gateways_id_seq'::regclass);


--
-- Name: plan_durations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_durations ALTER COLUMN id SET DEFAULT nextval('public.plan_durations_id_seq'::regclass);


--
-- Name: plan_prices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_prices ALTER COLUMN id SET DEFAULT nextval('public.plan_prices_id_seq'::regclass);


--
-- Name: plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans ALTER COLUMN id SET DEFAULT nextval('public.plans_id_seq'::regclass);


--
-- Name: referral_rewards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referral_rewards ALTER COLUMN id SET DEFAULT nextval('public.referral_rewards_id_seq'::regclass);


--
-- Name: referrals id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referrals ALTER COLUMN id SET DEFAULT nextval('public.referrals_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
0025
\.


--
-- Data for Name: broadcast_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.broadcast_messages (id, broadcast_id, user_telegram_id, message_id, status) FROM stdin;
\.


--
-- Data for Name: broadcasts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.broadcasts (id, task_id, status, audience, total_count, success_count, failed_count, payload, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_gateways; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_gateways (id, order_index, type, currency, is_active, settings) FROM stdin;
\.


--
-- Data for Name: plan_durations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_durations (id, days, plan_id, order_index) FROM stdin;
1	30	1	1
\.


--
-- Data for Name: plan_prices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_prices (id, currency, price, plan_duration_id) FROM stdin;
1	RUB	150.00	1
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plans (id, order_index, is_active, type, availability, name, traffic_limit, device_limit, allowed_user_ids, internal_squads, created_at, updated_at, description, tag, traffic_limit_strategy, external_squad, is_trial, public_code) FROM stdin;
1	1	t	DEVICES	ALL	Стандарт	0	2	{}	{11111111-1111-4111-8111-111111111111}	2025-12-01 10:00:00+02	2025-12-01 10:00:00+02	\N	\N	NO_RESET	\N	f	oldA0001
\.


--
-- Data for Name: referral_rewards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.referral_rewards (id, referral_id, user_telegram_id, type, amount, is_issued, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.referrals (id, referrer_telegram_id, referred_telegram_id, level, created_at, updated_at) FROM stdin;
1	3001	3002	FIRST	2025-12-03 12:00:00+02	2025-12-03 12:00:00+02
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, default_currency, referral, access, requirements, notifications, menu, created_at, updated_at, backup, blacklist) FROM stdin;
1	RUB	{"level": 1, "enable": true, "reward": {"type": "POINTS", "config": {"1": 10}, "strategy": "PERCENT"}, "accrual_strategy": "ON_FIRST_PAYMENT"}	{}	{}	{}	{}	2025-12-01 10:00:00+02	2025-12-01 10:00:00+02	{}	{}
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, user_remna_id, user_telegram_id, status, is_trial, traffic_limit, device_limit, internal_squads, expire_at, url, plan_snapshot, created_at, updated_at, external_squad, traffic_limit_strategy, tag) FROM stdin;
1	eeeeeeee-0000-4000-8000-000000000001	3001	ACTIVE	f	0	2	{11111111-1111-4111-8111-111111111111}	2026-12-15 12:00:00+02	https://sub.example.com/aNnaOld1	{"id": 1, "name": "Стандарт", "duration": 30, "device_limit": 2, "traffic_limit": 0}	2025-12-02 12:05:00+02	2026-11-15 12:00:00+02	\N	NO_RESET	\N
2	eeeeeeee-0000-4000-8000-000000000002	3002	ACTIVE	f	0	2	{11111111-1111-4111-8111-111111111111}	2026-12-16 12:00:00+02	https://sub.example.com/bOrisOld	{"id": 1, "name": "Стандарт", "duration": 30, "device_limit": 2, "traffic_limit": 0}	2025-12-03 12:05:00+02	2026-11-16 12:00:00+02	\N	NO_RESET	\N
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, payment_id, user_telegram_id, status, is_test, purchase_type, gateway_type, pricing, currency, plan_snapshot, created_at, updated_at) FROM stdin;
1	ffffffff-0000-4000-8000-000000000001	3001	COMPLETED	f	NEW	YOOMONEY	{"final_amount": 150, "original_amount": 150, "discount_percent": 0}	RUB	{"id": 1, "name": "Стандарт", "duration": 30}	2025-12-02 12:03:00+02	2025-12-02 12:04:00+02
2	ffffffff-0000-4000-8000-000000000002	3002	COMPLETED	f	NEW	YOOMONEY	{"final_amount": 150, "original_amount": 150, "discount_percent": 0}	RUB	{"id": 1, "name": "Стандарт", "duration": 30}	2025-12-03 12:03:00+02	2025-12-03 12:04:00+02
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, telegram_id, username, name, role, language, personal_discount, purchase_discount, is_blocked, is_bot_blocked, current_subscription_id, created_at, updated_at, referral_code, points, is_rules_accepted, is_trial_available) FROM stdin;
1	3001	anna_old	Анна	USER	RU	0	0	f	f	1	2025-12-02 12:00:00+02	2025-12-02 12:00:00+02	Oa11Aa	15	t	f
2	3002	\N	Борис	USER	RU	0	0	f	f	2	2025-12-03 12:00:00+02	2025-12-03 12:00:00+02	Ob22Bb	0	t	f
\.


--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.broadcast_messages_id_seq', 1, false);


--
-- Name: broadcasts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.broadcasts_id_seq', 1, false);


--
-- Name: payment_gateways_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_gateways_id_seq', 1, false);


--
-- Name: plan_durations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_durations_id_seq', 1, false);


--
-- Name: plan_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_prices_id_seq', 1, false);


--
-- Name: plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plans_id_seq', 1, false);


--
-- Name: referral_rewards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.referral_rewards_id_seq', 1, false);


--
-- Name: referrals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.referrals_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: broadcast_messages broadcast_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_pkey PRIMARY KEY (id);


--
-- Name: broadcasts broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_pkey PRIMARY KEY (id);


--
-- Name: broadcasts broadcasts_task_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_task_id_key UNIQUE (task_id);


--
-- Name: payment_gateways payment_gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_gateways
    ADD CONSTRAINT payment_gateways_pkey PRIMARY KEY (id);


--
-- Name: payment_gateways payment_gateways_type_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_gateways
    ADD CONSTRAINT payment_gateways_type_key UNIQUE (type);


--
-- Name: plan_durations plan_durations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_durations
    ADD CONSTRAINT plan_durations_pkey PRIMARY KEY (id);


--
-- Name: plan_prices plan_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_prices
    ADD CONSTRAINT plan_prices_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: referral_rewards referral_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_broadcast_messages_broadcast_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_broadcast_messages_broadcast_id ON public.broadcast_messages USING btree (broadcast_id);


--
-- Name: ix_broadcast_messages_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_broadcast_messages_status ON public.broadcast_messages USING btree (status);


--
-- Name: ix_broadcast_messages_user_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_broadcast_messages_user_telegram_id ON public.broadcast_messages USING btree (user_telegram_id);


--
-- Name: ix_broadcasts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_broadcasts_status ON public.broadcasts USING btree (status);


--
-- Name: ix_payment_gateways_order_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_gateways_order_index ON public.payment_gateways USING btree (order_index);


--
-- Name: ix_plan_durations_order_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_plan_durations_order_index ON public.plan_durations USING btree (order_index);


--
-- Name: ix_plans_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_plans_name ON public.plans USING btree (name);


--
-- Name: ix_plans_order_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_plans_order_index ON public.plans USING btree (order_index);


--
-- Name: ix_plans_public_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_plans_public_code ON public.plans USING btree (public_code);


--
-- Name: ix_referral_rewards_user_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_referral_rewards_user_telegram_id ON public.referral_rewards USING btree (user_telegram_id);


--
-- Name: ix_referrals_referred_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_referrals_referred_telegram_id ON public.referrals USING btree (referred_telegram_id);


--
-- Name: ix_referrals_referrer_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_referrals_referrer_telegram_id ON public.referrals USING btree (referrer_telegram_id);


--
-- Name: ix_subscriptions_expire_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_subscriptions_expire_at ON public.subscriptions USING btree (expire_at);


--
-- Name: ix_subscriptions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_subscriptions_status ON public.subscriptions USING btree (status);


--
-- Name: ix_subscriptions_user_remna_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_subscriptions_user_remna_id ON public.subscriptions USING btree (user_remna_id);


--
-- Name: ix_subscriptions_user_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_subscriptions_user_telegram_id ON public.subscriptions USING btree (user_telegram_id);


--
-- Name: ix_transactions_payment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_transactions_payment_id ON public.transactions USING btree (payment_id);


--
-- Name: ix_transactions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transactions_status ON public.transactions USING btree (status);


--
-- Name: ix_transactions_user_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transactions_user_telegram_id ON public.transactions USING btree (user_telegram_id);


--
-- Name: ix_users_referral_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_referral_code ON public.users USING btree (referral_code);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: broadcast_messages broadcast_messages_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.broadcasts(id) ON DELETE CASCADE;


--
-- Name: users fk_users_current_subscription_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_current_subscription_id FOREIGN KEY (current_subscription_id) REFERENCES public.subscriptions(id) ON DELETE SET NULL;


--
-- Name: plan_durations plan_durations_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_durations
    ADD CONSTRAINT plan_durations_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_prices plan_prices_plan_duration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_prices
    ADD CONSTRAINT plan_prices_plan_duration_id_fkey FOREIGN KEY (plan_duration_id) REFERENCES public.plan_durations(id) ON DELETE CASCADE;


--
-- Name: referral_rewards referral_rewards_referral_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_referral_id_fkey FOREIGN KEY (referral_id) REFERENCES public.referrals(id);


--
-- Name: referral_rewards referral_rewards_user_telegram_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_user_telegram_id_fkey FOREIGN KEY (user_telegram_id) REFERENCES public.users(telegram_id);


--
-- Name: referrals referrals_referred_telegram_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referred_telegram_id_fkey FOREIGN KEY (referred_telegram_id) REFERENCES public.users(telegram_id);


--
-- Name: referrals referrals_referrer_telegram_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referrer_telegram_id_fkey FOREIGN KEY (referrer_telegram_id) REFERENCES public.users(telegram_id);


--
-- Name: subscriptions subscriptions_user_telegram_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_telegram_id_fkey FOREIGN KEY (user_telegram_id) REFERENCES public.users(telegram_id) ON DELETE CASCADE;


--
-- Name: transactions transactions_user_telegram_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_telegram_id_fkey FOREIGN KEY (user_telegram_id) REFERENCES public.users(telegram_id);


--
-- PostgreSQL database dump complete
--

\unrestrict ATr5PXLfugRydJ0grQ5uW5fOGIY6XPpP8G2XY4LgBni7HAB36P8E1wr6S54ymi0

